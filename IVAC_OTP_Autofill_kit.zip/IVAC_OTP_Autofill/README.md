# IVAC OTP Autofill — setup (বাংলা নোট নিচে)

Three parts: **relay** (tiny Cloudflare Worker) · **Android app** (forwards the SMS code) · **extension v9.5** (fills it in).

## 1. Relay (one time, free Cloudflare account)
    cd relay
    npx wrangler login
    npx wrangler kv namespace create OTPS      # copy the printed id into wrangler.toml
    npx wrangler deploy                        # prints https://ivac-otp-relay.<you>.workers.dev
The relay keeps only the latest code per key for 5 minutes, and stores the key as a SHA-256 hash.

## 2. Android app
Open the `android/` folder in Android Studio → let it sync → Run (or Build > Build APK).
In the app: enter your phone number, the **Client key** from the extension (Config → Phone OTP auto-fill), and the **Relay URL**. Tap SAVE PAIRING and allow SMS.
Only SMS whose sender/body contains "IVAC" and a 6-digit code are forwarded; nothing else is read or stored. "Send a test push" sends 000000 to check the link.

## 3. Extension (v9.5)
Load the unpacked folder → Config tab → Phone OTP auto-fill → paste the same Relay URL, switch it **On**, copy the Client key into the phone app.
When the code arrives the six OTP boxes fill, the page field fills, and an alert plays. Auto-run then continues as before.

## বাংলায়
১) রিলে ডিপ্লয় করুন (উপরের কমান্ড)। ২) Android Studio-তে `android` ফোল্ডার খুলে অ্যাপ ইনস্টল করুন। ৩) এক্সটেনশনের Config → Phone OTP auto-fill-এ Relay URL দিয়ে অন করুন, Client key কপি করে ফোনের অ্যাপে বসান। এরপর IVAC-এর OTP SMS এলেই বক্সে বসে যাবে।

Notes: the relay URL must be https and end in workers.dev (the extension is only allowed to reach *.workers.dev). The client key is the secret — anyone with it can read your latest OTP, so don't share it; use NEW in the extension to rotate it.

## No Android Studio? Build the APK online (GitHub Actions)
1. Make a free GitHub account → New repository (private is fine).
2. Upload the *contents* of the `android` folder (including the hidden `.github` folder) to the repo.
3. Repo → Actions tab → "Build APK" → Run workflow. After ~5 min open the run → Artifacts → download `IVAC-OTP-Autofill-apk` → unzip → `app-debug.apk`.
4. Send the APK to the phone and install it (allow "Unknown sources").
